<?php
/**
 * Created by PhpStorm.
 * User: zhangjun
 * Date: 21/11/2018
 * Time: 11:35 AM
 */

class MiniProgram_CustomerService_ConfigController
{
    const ENABLE_CUSTOMER_SERVICE = "enableCustomerService"; //开启客服

    const GREETING = "greeting";//第一句打招呼

    const CHAT_TITLE = "chatTitle";

    const SIGN_VERIFY_KEY = "signVerifyKey";

}