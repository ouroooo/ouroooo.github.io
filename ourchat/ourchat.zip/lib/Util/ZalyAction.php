<?php
/**
 * Created by PhpStorm.
 * User: zhangjun
 * Date: 21/07/2018
 * Time: 4:51 PM
 */

class  ZalyAction
{
    public $apiGroupCreate = "api.group.create";
}