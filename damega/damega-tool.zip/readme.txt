[对于windows用户]
本脚本需要python环境，不会搭建环境的可以参考菜鸟教程[https://www.runoob.com/python/python-install.html]
环境搭建好后直接双击运行即可
#
[对于安卓用户]
本脚本推荐搭配Pydroid3[https://blog.qaiu.top/archives/pydroid3v70]使用
在Pydroid3内打开脚本后点击运行即可